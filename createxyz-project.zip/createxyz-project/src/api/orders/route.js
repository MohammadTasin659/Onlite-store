async function handler({
  fullName,
  contactNumber,
  contactEmail,
  notes,
  addressLine1,
  addressLine2,
  city,
  state,
  postalCode,
  country,
  items,
}) {
  const session = await getSession();
  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  try {
    // Start a transaction since we're making multiple related changes
    return await sql.transaction(async (sql) => {
      // First create the shipping address
      const [shippingAddress] = await sql`
        INSERT INTO shipping_addresses (
          user_id,
          address_line1,
          address_line2,
          city,
          state,
          postal_code,
          country
        ) VALUES (
          ${session.user.id},
          ${addressLine1},
          ${addressLine2 || null},
          ${city},
          ${state},
          ${postalCode},
          ${country}
        )
        RETURNING id
      `;

      // Create the order
      const [order] = await sql`
        INSERT INTO orders (
          user_id,
          status,
          total_amount,
          shipping_address_id,
          notes,
          contact_email,
          contact_number,
          full_name
        ) VALUES (
          ${session.user.id},
          'pending',
          ${items.reduce(
            (total, item) => total + item.price * item.quantity,
            0
          )},
          ${shippingAddress.id},
          ${notes || null},
          ${contactEmail},
          ${contactNumber},
          ${fullName}
        )
        RETURNING id
      `;

      // Create order items
      await sql`
        INSERT INTO order_items (
          order_id,
          product_id,
          quantity,
          price_at_time
        )
        SELECT 
          ${order.id},
          p.id,
          i.quantity,
          p.price
        FROM unnest($1::int[], $2::int[]) AS i(product_id, quantity)
        JOIN products p ON p.id = i.product_id
      `([items.map((i) => i.productId), items.map((i) => i.quantity)]);

      // Update product stock
      for (const item of items) {
        await sql`
          UPDATE products
          SET stock = stock - ${item.quantity}
          WHERE id = ${item.productId}
          AND stock >= ${item.quantity}
        `;
      }

      return { orderId: order.id };
    });
  } catch (error) {
    console.error("Error creating order:", error);
    return { error: "Failed to create order" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}