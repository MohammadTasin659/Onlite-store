async function handler() {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  const vendor = await sql`
    SELECT id FROM vendors 
    WHERE user_id = ${session.user.id}
  `;

  if (!vendor?.length) {
    return { error: "Vendor not found" };
  }

  const vendorId = vendor[0].id;

  const orders = await sql`
    SELECT 
      o.id as order_id,
      o.status,
      o.total_amount,
      o.created_at,
      o.full_name,
      o.contact_number,
      o.contact_email,
      o.notes,
      oi.quantity,
      oi.price_at_time,
      p.name as product_name,
      p.id as product_id,
      sa.address_line1,
      sa.address_line2,
      sa.city,
      sa.state,
      sa.postal_code,
      sa.country
    FROM orders o
    JOIN order_items oi ON o.id = oi.order_id
    JOIN products p ON oi.product_id = p.id
    LEFT JOIN shipping_addresses sa ON o.shipping_address_id = sa.id
    WHERE p.vendor_id = ${vendorId}
    ORDER BY o.created_at DESC
  `;

  return { orders };
}
export async function POST(request) {
  return handler(await request.json());
}