async function handler() {
  try {
    const products = await sql`
      SELECT 
        p.id,
        p.name,
        p.description,
        p.price,
        p.stock,
        p.image_url,
        p.created_at,
        v.business_name as vendor_name
      FROM products p
      LEFT JOIN vendors v ON p.vendor_id = v.id
      ORDER BY p.created_at DESC
    `;

    return products;
  } catch (error) {
    return {
      error: "Failed to fetch products",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}