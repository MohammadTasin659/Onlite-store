async function handler({ method, body, query }) {
  const session = getSession();
  const { id, page = 1, limit = 10, search } = query || {};
  const offset = (page - 1) * limit;

  switch (method) {
    case "GET":
      if (id) {
        const [product] = await sql`
          SELECT p.*, v.business_name as vendor_name 
          FROM products p
          LEFT JOIN vendors v ON p.vendor_id = v.id
          WHERE p.id = ${id}
        `;
        return product || { error: "Product not found" };
      }

      let queryStr = `
        SELECT p.*, v.business_name as vendor_name 
        FROM products p
        LEFT JOIN vendors v ON p.vendor_id = v.id
      `;
      const values = [];
      let paramCount = 0;

      if (search) {
        queryStr += ` WHERE LOWER(p.name) LIKE LOWER($${++paramCount}) 
          OR LOWER(p.description) LIKE LOWER($${++paramCount})`;
        values.push(`%${search}%`, `%${search}%`);
      }

      queryStr += ` LIMIT $${++paramCount} OFFSET $${++paramCount}`;
      values.push(limit, offset);

      const products = await sql(queryStr, values);
      return { products };

    case "POST":
      if (!session?.user?.id) {
        return { error: "Unauthorized" };
      }

      const [vendor] = await sql`
        SELECT id FROM vendors WHERE user_id = ${session.user.id}
      `;

      if (!vendor) {
        return { error: "Must be a vendor to create products" };
      }

      const { name, description, price, stock, image_url } = body;

      const [newProduct] = await sql`
        INSERT INTO products (
          vendor_id, name, description, price, stock, image_url
        ) VALUES (
          ${vendor.id}, ${name}, ${description}, ${price}, ${stock}, ${image_url}
        )
        RETURNING *
      `;

      return newProduct;

    case "PUT":
      if (!session?.user?.id || !id) {
        return { error: "Unauthorized" };
      }

      const [existingProduct] = await sql`
        SELECT p.* FROM products p
        JOIN vendors v ON p.vendor_id = v.id
        WHERE p.id = ${id} AND v.user_id = ${session.user.id}
      `;

      if (!existingProduct) {
        return { error: "Product not found or unauthorized" };
      }

      const updates = [];
      const updateValues = [];
      let pCount = 0;

      if (body.name) {
        updates.push(`name = $${++pCount}`);
        updateValues.push(body.name);
      }
      if (body.description) {
        updates.push(`description = $${++pCount}`);
        updateValues.push(body.description);
      }
      if (body.price) {
        updates.push(`price = $${++pCount}`);
        updateValues.push(body.price);
      }
      if (body.stock !== undefined) {
        updates.push(`stock = $${++pCount}`);
        updateValues.push(body.stock);
      }
      if (body.image_url) {
        updates.push(`image_url = $${++pCount}`);
        updateValues.push(body.image_url);
      }

      if (updates.length === 0) {
        return existingProduct;
      }

      updateValues.push(id);
      const [updatedProduct] = await sql(
        `UPDATE products SET ${updates.join(
          ", "
        )} WHERE id = $${++pCount} RETURNING *`,
        updateValues
      );

      return updatedProduct;

    case "DELETE":
      if (!session?.user?.id || !id) {
        return { error: "Unauthorized" };
      }

      const [deletedProduct] = await sql`
        DELETE FROM products p
        USING vendors v
        WHERE p.id = ${id}
        AND p.vendor_id = v.id
        AND v.user_id = ${session.user.id}
        RETURNING p.*
      `;

      return deletedProduct || { error: "Product not found or unauthorized" };

    default:
      return { error: "Method not allowed" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}