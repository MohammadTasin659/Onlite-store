"use client";
import React from "react";

function MainComponent() {
  const [error, setError] = useState(null);
  const { data: user, loading } = useUser();
  const [products, setProducts] = useState([]);
  const [loadingProducts, setLoadingProducts] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch("/api/products?method=GET");
        if (!response.ok) {
          throw new Error("Failed to fetch products");
        }
        const data = await response.json();
        setProducts(data.products || []);
      } catch (err) {
        console.error(err);
        setError("Failed to load products");
      } finally {
        setLoadingProducts(false);
      }
    };

    fetchProducts();
  }, []);

  const handleBecomeVendor = async () => {
    if (!user) {
      window.location.href = "/account/signin?callbackUrl=/";
      return;
    }
    // Redirect to vendor registration page (we'll create this next)
    window.location.href = "/vendor/register";
  };

  return (
    <div className="min-h-screen bg-white">
      <nav className="bg-white shadow-sm">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="text-2xl font-bold text-[#357AFF]">MarketPlace</div>
            <div className="flex items-center space-x-4">
              {!loading && !user && (
                <>
                  <a
                    href="/account/signin"
                    className="text-gray-600 hover:text-[#357AFF]"
                  >
                    Sign In
                  </a>
                  <a
                    href="/account/signup"
                    className="rounded-lg bg-[#357AFF] px-4 py-2 text-white hover:bg-[#2E69DE]"
                  >
                    Sign Up
                  </a>
                </>
              )}
              {user && (
                <a
                  href="/account/logout"
                  className="text-gray-600 hover:text-[#357AFF]"
                >
                  Sign Out
                </a>
              )}
            </div>
          </div>
        </div>
      </nav>

      <section className="bg-gradient-to-br from-blue-50 to-indigo-50 px-4 py-20 text-center">
        <div className="mx-auto max-w-4xl">
          <h1 className="mb-6 text-4xl font-bold text-gray-900 sm:text-5xl">
            Your One-Stop Marketplace for Everything
          </h1>
          <p className="mb-8 text-xl text-gray-600">
            Shop from thousands of vendors or start selling your products today
          </p>
          <div className="flex flex-col items-center justify-center space-y-4 sm:flex-row sm:space-x-4 sm:space-y-0">
            <a
              href="/products"
              className="w-full rounded-lg bg-[#357AFF] px-8 py-3 text-lg font-semibold text-white hover:bg-[#2E69DE] sm:w-auto"
            >
              Start Shopping
            </a>
            <button
              onClick={handleBecomeVendor}
              className="w-full rounded-lg border-2 border-[#357AFF] px-8 py-3 text-lg font-semibold text-[#357AFF] hover:bg-[#357AFF] hover:text-white sm:w-auto"
            >
              Become a Vendor
            </button>
          </div>
        </div>
      </section>

      <section className="px-4 py-16">
        <div className="mx-auto max-w-7xl">
          <h2 className="mb-12 text-center text-3xl font-bold text-gray-900">
            Featured Products
          </h2>
          {error && (
            <div className="mb-8 text-center text-red-500">{error}</div>
          )}
          {loadingProducts ? (
            <div className="text-center text-gray-600">Loading products...</div>
          ) : (
            <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
              {products.map((product) => (
                <div
                  key={product.id}
                  className="overflow-hidden rounded-lg border bg-white shadow-sm transition-transform hover:scale-105"
                >
                  {product.image_url ? (
                    <img
                      src={product.image_url}
                      alt={product.name}
                      className="h-48 w-full object-cover"
                    />
                  ) : (
                    <div className="h-48 bg-gray-200"></div>
                  )}
                  <div className="p-4">
                    <h3 className="mb-2 text-lg font-semibold text-gray-900">
                      {product.name}
                    </h3>
                    <p className="mb-2 text-gray-600">
                      ${product.price.toFixed(2)}
                    </p>
                    <p className="text-sm text-gray-500">
                      By {product.vendor_name}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="bg-gray-50 px-4 py-16">
        <div className="mx-auto max-w-7xl">
          <h2 className="mb-12 text-center text-3xl font-bold text-gray-900">
            Why Become a Vendor?
          </h2>
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-3">
            <div className="rounded-lg bg-white p-6 text-center shadow-sm">
              <div className="mb-4 text-4xl text-[#357AFF]">
                <i className="fas fa-globe"></i>
              </div>
              <h3 className="mb-2 text-xl font-semibold text-gray-900">
                Global Reach
              </h3>
              <p className="text-gray-600">
                Access customers from around the world
              </p>
            </div>
            <div className="rounded-lg bg-white p-6 text-center shadow-sm">
              <div className="mb-4 text-4xl text-[#357AFF]">
                <i className="fas fa-chart-line"></i>
              </div>
              <h3 className="mb-2 text-xl font-semibold text-gray-900">
                Growth Tools
              </h3>
              <p className="text-gray-600">
                Analytics and tools to grow your business
              </p>
            </div>
            <div className="rounded-lg bg-white p-6 text-center shadow-sm">
              <div className="mb-4 text-4xl text-[#357AFF]">
                <i className="fas fa-shield-alt"></i>
              </div>
              <h3 className="mb-2 text-xl font-semibold text-gray-900">
                Secure Platform
              </h3>
              <p className="text-gray-600">Safe and secure transactions</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default MainComponent;